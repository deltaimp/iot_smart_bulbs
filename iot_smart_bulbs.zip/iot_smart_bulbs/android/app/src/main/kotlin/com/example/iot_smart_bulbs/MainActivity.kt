package com.example.iot_smart_bulbs

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
