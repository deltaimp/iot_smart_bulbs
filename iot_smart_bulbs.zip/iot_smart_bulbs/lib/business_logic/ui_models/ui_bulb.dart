import 'package:iot_smart_bulbs/data/models/bulb.dart';

class UIBulb extends Bulb {

}