enum BulbState {
  ACCESA,
  SPENTA
}